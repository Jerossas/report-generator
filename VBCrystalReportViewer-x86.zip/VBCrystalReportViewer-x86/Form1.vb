﻿Imports CrystalDecisions.CrystalReports.Engine
Imports System.IO

Public Class Form1

    Private ReporteCrystal As ReportDocument
    Private PlaceholderText As String = "Ingrese su consulta aquí..."

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Inicializar el objeto ReportDocument
        ReporteCrystal = New ReportDocument()

        ' Establecer el placeholder en el TextBox de consulta
        txtConsulta.Text = PlaceholderText
        txtConsulta.ForeColor = Color.Gray
    End Sub

    ' Evento para seleccionar el archivo del reporte
    Private Sub btnBuscarReporte_Click(sender As Object, e As EventArgs)
        Using openFileDialog As New OpenFileDialog()
            openFileDialog.Filter = "Archivos Crystal Reports (*.rpt)|*.rpt"
            openFileDialog.Title = "Seleccione un Reporte"

            If openFileDialog.ShowDialog() = DialogResult.OK Then
                txtRutaReporte.Text = openFileDialog.FileName
            End If
        End Using
    End Sub

    ' Evento para cargar el reporte seleccionado
    Private Sub btnCargarReporte_Click(sender As Object, e As EventArgs)
        Try
            Dim rutaReporte As String = txtRutaReporte.Text
            Dim consulta As String = txtConsulta.Text.Trim()

            ' Validar que el archivo existe
            If String.IsNullOrEmpty(rutaReporte) OrElse Not File.Exists(rutaReporte) Then
                MessageBox.Show("Por favor, seleccione un archivo de reporte válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            ' Cargar el reporte
            ReporteCrystal.Load(rutaReporte)

            ' Si la consulta está vacía, se limpia cualquier filtro anterior
            If String.IsNullOrWhiteSpace(consulta) OrElse consulta = PlaceholderText Then
                ReporteCrystal.RecordSelectionFormula = ""
            Else
                Try
                    ReporteCrystal.RecordSelectionFormula = consulta
                Catch ex As Exception
                    MessageBox.Show("Advertencia: No se pudo aplicar la consulta. Se mostrará el reporte sin filtro." & vbCrLf & ex.Message, "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End Try
            End If

            ' Refrescar Reporte
            ReporteCrystal.Refresh()

            ' Mostrar el reporte en el visor
            ReportViewerForm.ReportSource = ReporteCrystal
            ReportViewerForm.Show()

        Catch ex As Exception
            MessageBox.Show("Ocurrió un error al cargar el reporte: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Placeholder en el TextBox de consulta
    Private Sub txtConsulta_Enter(sender As Object, e As EventArgs) Handles txtConsulta.Enter
        If txtConsulta.Text = PlaceholderText Then
            txtConsulta.Text = ""
            txtConsulta.ForeColor = Color.Black
        End If
    End Sub

    Private Sub txtConsulta_Leave(sender As Object, e As EventArgs) Handles txtConsulta.Leave
        If String.IsNullOrWhiteSpace(txtConsulta.Text) Then
            txtConsulta.Text = PlaceholderText
            txtConsulta.ForeColor = Color.Gray
        End If
    End Sub

    ' Liberar recursos cuando se cierra el formulario
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Try
            If ReporteCrystal IsNot Nothing Then
                ReporteCrystal.Close()
                ReporteCrystal.Dispose()
            End If
        Catch ex As Exception
            MessageBox.Show("Ocurrió un error al liberar los recursos: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class
