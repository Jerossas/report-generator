# Aplicación - Versión x86 (32 bits)

## Descripción
Esta es la versión de **32 bits** de la aplicación, diseñada para ejecutarse en entornos Windows de 32 bits con soporte para Crystal Reports.

---

## Tecnologías Utilizadas
- **Lenguaje**: Visual Basic (.NET Framework)
- **Reportes**: SAP Crystal Reports
- **Arquitectura**: 32 bits (x86)

---

## Requisitos del Sistema
- **Sistema Operativo**: Windows 10/11 (32 bits) o 64 bits con compatibilidad x86
- **.NET Framework**: 4.8 o superior
- **Crystal Reports Runtime (32 bits)**: SAP Crystal Reports for Visual Studio (SP37) CR runtime MSI (32-bit)

---

## Instalación
### **Instalar Dependencias**
1. Instalar **Crystal Reports Runtime (x86)**.

### **Ejecutar la Aplicación**
1. Abrir el archivo `\bin\release\VBCrystalReportViewer-x86.exe` en un entorno de **32 bits**.
2. Si es necesario, ejecutar con permisos de administrador.

---

## 🏆 Créditos
- **Fecha**: 09/03/2025
- **Versión**: x86 v1.0