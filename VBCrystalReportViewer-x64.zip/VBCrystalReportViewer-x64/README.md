# Aplicación - Versión x64 (64 bits)

## Descripción
Esta es la versión de **64 bits** de la aplicación, diseñada para ejecutarse en entornos Windows de 64 bits con soporte para Crystal Reports.

---

## Tecnologías Utilizadas
- **Lenguaje**: Visual Basic (.NET Framework)
- **Reportes**: SAP Crystal Reports
- **Arquitectura**: 64 bits (x64)

---

## Requisitos del Sistema
- **Sistema Operativo**: Windows 10/11 (64 bits)
- **.NET Framework**: 4.8 o superior
- **Crystal Reports Runtime (64 bits)**: SAP Crystal Reports for Visual Studio (SP37) CR runtime MSI (64-bit)

---

## Instalación
### **1️⃣ Instalar Dependencias**
1. Instalar **Crystal Reports Runtime (x64)**.

### **2️⃣ Ejecutar la Aplicación**
1. Abrir el archivo `\bin\release\VBCrystalReportViewer-x64.exe` en un entorno de **64 bits**.
2. Si es necesario, ejecutar con permisos de administrador.

---

## 🏆 Créditos
- **Fecha**: 09/03/2025
- **Versión**: x64 v1.0

