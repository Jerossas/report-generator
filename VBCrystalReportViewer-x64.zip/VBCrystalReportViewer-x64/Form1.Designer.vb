﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    ' Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    ' Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.pnlControles = New System.Windows.Forms.Panel()
        Me.txtRutaReporte = New System.Windows.Forms.TextBox()
        Me.btnBuscarReporte = New System.Windows.Forms.Button()
        Me.txtConsulta = New System.Windows.Forms.TextBox()
        Me.btnCargarReporte = New System.Windows.Forms.Button()
        Me.ReportViewerForm = New CrystalDecisions.Windows.Forms.CrystalReportViewer()

        Me.SuspendLayout()

        ' --- PANEL DE CONTROLES ---
        Me.pnlControles.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlControles.Height = 60
        Me.pnlControles.Controls.Add(Me.txtRutaReporte)
        Me.pnlControles.Controls.Add(Me.btnBuscarReporte)
        Me.pnlControles.Controls.Add(Me.txtConsulta)
        Me.pnlControles.Controls.Add(Me.btnCargarReporte)

        ' TextBox para la ruta del reporte
        Me.txtRutaReporte.Name = "txtRutaReporte"
        Me.txtRutaReporte.Location = New System.Drawing.Point(10, 10)
        Me.txtRutaReporte.Size = New System.Drawing.Size(350, 20)
        Me.txtRutaReporte.ReadOnly = True

        ' Botón para seleccionar reporte
        Me.btnBuscarReporte.Name = "btnBuscarReporte"
        Me.btnBuscarReporte.Location = New System.Drawing.Point(370, 8)
        Me.btnBuscarReporte.Size = New System.Drawing.Size(120, 25)
        Me.btnBuscarReporte.Text = "Buscar Reporte"
        AddHandler Me.btnBuscarReporte.Click, AddressOf Me.btnBuscarReporte_Click

        ' TextBox para ingresar la consulta con placeholder
        Me.txtConsulta.Name = "txtConsulta"
        Me.txtConsulta.Location = New System.Drawing.Point(10, 35)
        Me.txtConsulta.Size = New System.Drawing.Size(350, 20)

        ' Botón para cargar el reporte
        Me.btnCargarReporte.Name = "btnCargarReporte"
        Me.btnCargarReporte.Location = New System.Drawing.Point(370, 33)
        Me.btnCargarReporte.Size = New System.Drawing.Size(120, 25)
        Me.btnCargarReporte.Text = "Cargar Reporte"
        AddHandler Me.btnCargarReporte.Click, AddressOf Me.btnCargarReporte_Click

        ' --- VISOR DE CRYSTAL REPORTS ---
        Me.ReportViewerForm.Name = "ReportGeneratorForm"
        Me.ReportViewerForm.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReportViewerForm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ReportViewerForm.Location = New System.Drawing.Point(0, 60)
        Me.ReportViewerForm.Size = New System.Drawing.Size(800, 500)
        Me.ReportViewerForm.TabIndex = 0

        ' --- FORMULARIO PRINCIPAL ---
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 600)
        Me.Controls.Add(Me.ReportViewerForm)
        Me.Controls.Add(Me.pnlControles)
        Me.Name = "Form1"
        Me.Text = "Visor de Reportes"
        Me.WindowState = FormWindowState.Normal

        Me.ResumeLayout(False)
        Me.PerformLayout()
    End Sub

    Friend WithEvents pnlControles As System.Windows.Forms.Panel
    Friend WithEvents txtRutaReporte As System.Windows.Forms.TextBox
    Friend WithEvents btnBuscarReporte As System.Windows.Forms.Button
    Friend WithEvents txtConsulta As System.Windows.Forms.TextBox
    Friend WithEvents btnCargarReporte As System.Windows.Forms.Button
    Friend WithEvents ReportViewerForm As CrystalDecisions.Windows.Forms.CrystalReportViewer

End Class
